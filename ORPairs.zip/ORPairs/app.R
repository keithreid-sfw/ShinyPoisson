#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)

# Define UI for application that draws a histogram
ui <- fluidPage(

    # Application title
    titlePanel("Behaviour of Poisson with variable Lambda"),

    # Sidebar with a slider input for number of bins 
    sidebarLayout(
        sidebarPanel(
            sliderInput("my_lambda",
                        "Expected number of events:",
                        min = 1,
                        max = 32,
                        value = 16)
        ),
        
        #sidebarPanel(
        #  sliderInput("my_range",
        #              "Maximum number of events:",
        #              min = 1,
        #              max = 32,
        #              value = 16)
        #),

        # Show a plot of the generated distribution
        mainPanel(
           plotOutput("distPlot")
        )
    )
)

# Define server logic required to draw a histogram
server <- function(input, output) {

    output$distPlot <- renderPlot({
        # generate bins based on input$bins from ui.R
        
        #number_of_events <- seq(0, input$my_range, by = 1) # Specify x-values for dpois function
        number_of_events <- seq(0, 32, by = 1) # Specify x-values for dpois function
        exact_probability <- dpois(number_of_events, lambda = input$my_lambda)  #Apply dpois function
       
       #      xlab = 'Waiting time to next eruption (in mins)',
        #     main = 'Histogram of waiting times')
        plot(number_of_events, exact_probability)
    })
}

# Run the application 
shinyApp(ui = ui, server = server)
